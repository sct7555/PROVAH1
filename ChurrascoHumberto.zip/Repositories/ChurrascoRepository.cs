﻿using ChurrascoHumberto.Entities;
using ChurrascoHumberto.Interfaces;

namespace ChurrascoHumberto.Repositories
{
    public class ChurrascoRepository : IChurrascoRepository
    {
        private static List<Participante> _db;

        public ChurrascoRepository()
        {
            _db ??= new List<Participante>();
        }

        public void Add(Participante part)
        {
            _db.Add(part);
        }

        public List<Participante> GetAll()
        {
            return _db;
        }
    }
}
