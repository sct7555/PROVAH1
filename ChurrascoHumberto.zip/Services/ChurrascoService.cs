﻿using ChurrascoHumberto.Entities;
using ChurrascoHumberto.Interfaces;

namespace ChurrascoHumberto.Services
{
    public class ChurrascoService : IChurrascoService
    {
        private readonly IChurrascoRepository _repo;

        public ChurrascoService(IChurrascoRepository repo)
        {
            _repo = repo;
        }

        public void Add(Participante part)
        {
            _repo.Add(part);
        }

        public List<Participante> GetAll()
        {
            return _repo.GetAll();
        }
    }
}
