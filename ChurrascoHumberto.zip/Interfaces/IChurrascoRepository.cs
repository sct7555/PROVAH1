﻿using ChurrascoHumberto.Entities;

namespace ChurrascoHumberto.Interfaces
{
    public interface IChurrascoRepository
    {
        public void Add(Participante part);
        public List<Participante> GetAll();
    }
}
