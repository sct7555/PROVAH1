﻿using ChurrascoHumberto.Entities;
using ChurrascoHumberto.Models;

namespace ChurrascoHumberto.Interfaces
{
    public interface IChurrascoService
    {
        public void Add(Participante newPart);
        public List<Participante> GetAll();
    }
}
