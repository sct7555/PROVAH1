﻿using ChurrascoHumberto.Entities;
using ChurrascoHumberto.Interfaces;
using ChurrascoHumberto.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChurrascoHumberto.Controllers
{
    public class ChurrascoController : ControllerBase
    {
        private readonly IChurrascoService _service;

        public ChurrascoController(IChurrascoService service)
        {
            _service = service;
        }

        [HttpPost("Adicionar-Participante")]
        public IActionResult AdicionarParticipante(NovoParticipante part)
        {
            try
            {
                var newPart = new Participante()
                {
                    DescBebidas = part.DescBebidas,
                    DescCarne = part.DescCarne,
                    Idade = part.Idade,
                    Nome = part.Nome
                };

                _service.Add(newPart);
                return Ok(newPart);
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("Participantes")]
        public IActionResult Participantes()
        {
            try
            {
                return Ok(_service.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
