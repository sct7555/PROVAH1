﻿using System.ComponentModel.DataAnnotations;

namespace ChurrascoHumberto.Models
{
    public class NovoParticipante
    {
        [Required]
        [MaxLength(255)]
        [MinLength(3)]
        public string Nome { get; set; }

        [Required]
        public string DescCarne { get; set; }

        [Required]
        [Range(0, 17)]
        public int Idade { get; set; }

        [Required]
        public string DescBebidas { get; set; }
    }
}
