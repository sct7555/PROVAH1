﻿using System.ComponentModel.DataAnnotations;

namespace ChurrascoHumberto.Entities
{
    public class Participante
    {
        public string Nome { get; set; }

        public string DescCarne { get; set; }

        public int Idade { get; set; }

        public string DescBebidas { get; set; }
    }
}
